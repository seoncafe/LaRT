#!/bin/bash
exec < /dev/null 2>&1
trap "" HUP

EXEC=../../LaRT.x

#HOSTS=`hostname`
#HOSTS=mocafe
#HOSTS=mocafe,lart2
#HOSTS=mocafe,lart1,lart2,lart3
HOSTS=lart4,lart3,lart2,lart1

mpirun -hosts $HOSTS -ppn 1 $EXEC rin0.1_Vrot100_NHI18.in
mpirun -hosts $HOSTS -ppn 1 $EXEC rin0.1_Vrot300_NHI18.in
