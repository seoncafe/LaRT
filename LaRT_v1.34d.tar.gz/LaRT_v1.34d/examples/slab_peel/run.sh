#!/bin/bash
exec < /dev/null 2>&1
trap "" HUP

EXEC=../../LaRT.x

HOSTS=mocafe
#HOSTS=mocafe,lart2
#HOSTS=mocafe,lart1,lart2,lart3

#====== Do not touch starting from here =========
NTHREADS=0
array=$(echo $HOSTS | tr "," "\n")
for host in $array
do
   if [[ $host = "mocafe" ]]
   then
      num=88
   else
      num=72
   fi
   NTHREADS=$((num + NTHREADS))
done
options=$(echo -np $NTHREADS -hosts $HOSTS -bind-to none)
#====== Do not touch up to here =========

echo ""
echo "Running $EXEC on $HOSTS with $NTHREADS threads."
echo "   using options: $options"

#---
mpirun $options $EXEC t1tau4.in
mpirun $options $EXEC t1tau5.in
mpirun $options $EXEC t1tau6.in
mpirun $options $EXEC t1tau7.in

mpirun $options $EXEC t4tau4.in
mpirun $options $EXEC t4tau5.in
mpirun $options $EXEC t4tau6.in
mpirun $options $EXEC t4tau7.in

mpirun $options $EXEC t2tau4.in
mpirun $options $EXEC t2tau5.in
mpirun $options $EXEC t2tau6.in
mpirun $options $EXEC t2tau7.in

mpirun $options $EXEC t3tau4.in
mpirun $options $EXEC t3tau5.in
mpirun $options $EXEC t3tau6.in
mpirun $options $EXEC t3tau7.in
