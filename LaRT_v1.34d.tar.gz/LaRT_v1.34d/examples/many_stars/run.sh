#!/bin/bash
exec < /dev/null 2>&1
trap "" HUP

EXEC=../../LaRT.x

HOSTS=mocafe
#HOSTS=mocafe,lart2
#HOSTS=mocafe,lart1,lart2,lart3

#====== Do not touch starting from here =========
NTHREADS=0
array=$(echo $HOSTS | tr "," "\n")
for host in $array
do
   if [[ $host = "mocafe" ]]
   then
      num=88
   else
      num=72
   fi
   NTHREADS=$((num + NTHREADS))
done
options=$(echo -np $NTHREADS -hosts $HOSTS -bind-to none)
#====== Do not touch up to here =========

echo ""
echo "Running $EXEC on $HOSTS with $NTHREADS threads."
echo "   using options: $options"

#mpirun $options $EXEC stars1.in
mpirun $options $EXEC stars2.in
