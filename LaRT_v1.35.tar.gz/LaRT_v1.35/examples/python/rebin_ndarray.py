import numpy as np

def ResampleLinear1D(original, targetLen):
    original    = np.array(original, dtype=np.float64)
    index_arr   = np.linspace(0, len(original)-1, num=targetLen, dtype=np.float64)
    index_floor = np.array(index_arr, dtype=np.int32) #Round down
    index_ceil  = index_floor + 1
    index_rem   = index_arr - index_floor #Remain

    val1   = original[index_floor]
    val2   = original[index_ceil % len(original)]
    interp = val1 * (1.0-index_rem) + val2 * index_rem
    assert(len(interp) == targetLen)
    return interp

def bin_ndarray(ndarray, new_shape, operation='mean'):
    #--- from https://gist.github.com/derricw/95eab740e1b08b78c03f
    """
    Bins an ndarray in all axes based on the target shape, by summing or
        averaging.
    Number of output dimensions must match number of input dimensions.
    Example
    -------
    >>> m = np.arange(0,100,1).reshape((10,10))
    >>> n = bin_ndarray(m, new_shape=(5,5), operation='sum')
    >>> print(n)
    [[ 22  30  38  46  54]
     [102 110 118 126 134]
     [182 190 198 206 214]
     [262 270 278 286 294]
     [342 350 358 366 374]]
    """
    if not operation.lower() in ['sum', 'mean', 'average', 'avg']:
        raise ValueError("Operation {} not supported.".format(operation))
    if ndarray.ndim != len(new_shape):
        raise ValueError("Shape mismatch: {} -> {}".format(ndarray.shape,
                                                           new_shape))
    compression_pairs = [(d, c//d) for d, c in zip(new_shape,
                                                   ndarray.shape)]
    flattened = [l for p in compression_pairs for l in p]
    ndarray = ndarray.reshape(flattened)
    for i in range(len(new_shape)):
        if operation.lower() == "sum":
            ndarray = ndarray.sum(-1*(i+1))
        elif operation.lower() in ["mean", "average", "avg"]:
            ndarray = ndarray.mean(-1*(i+1))
    return ndarray

def rebin_ndarray(ndarray, new_shape, operation='mean'):
    return bin_ndarray(ndarray, new_shape, operation=operation)

def rebin(ndarray, new_shape, operation='mean'):
    return bin_ndarray(ndarray, new_shape, operation=operation)
