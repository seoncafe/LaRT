#!/bin/bash
exec < /dev/null 2>&1
trap "" HUP

EXEC=../../LaRT.x
HOST=all_hosts

mpirun -machinefile $HOST $EXEC MUSE1185.in
mpirun -machinefile $HOST $EXEC MUSE0082.in
mpirun -machinefile $HOST $EXEC MUSE6905.in
mpirun -machinefile $HOST $EXEC MUSE1343.in
mpirun -machinefile $HOST $EXEC MUSE0053.in
mpirun -machinefile $HOST $EXEC MUSE0171.in
mpirun -machinefile $HOST $EXEC MUSE0547.in
mpirun -machinefile $HOST $EXEC MUSE0364.in
