#!/bin/bash
exec < /dev/null 2>&1
trap "" HUP

EXEC=../../LaRT.x
HOSTS=mocafe,lart1,lart2,lart3,lart4

mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE1185.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE0082.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE6905.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE1343.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE0053.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE0171.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE0547.in
#mpirun -hosts $HOSTS -ppn 1 $EXEC MUSE0364.in
